"""Geometric face tracks with bounded, temporally confirmed expression inference."""
import math

import cv2


def _iou(a, b):
    left, top = max(a[0], b[0]), max(a[1], b[1])
    right, bottom = min(a[0]+a[2], b[0]+b[2]), min(a[1]+a[3], b[1]+b[3])
    overlap = max(0, right-left)*max(0, bottom-top)
    return overlap/max(1e-9, a[2]*a[3]+b[2]*b[3]-overlap)


class FaceTracks:
    def __init__(self, recognizer=None, threshold=.7):
        self.recognizer = recognizer
        self.threshold = threshold
        self.tracks = {}
        self.next_id = 1

    def update(self, frame, gray, detections, time, cut, level, audio_gate):
        if cut:
            self.tracks.clear()
        self.tracks = {key:value for key,value in self.tracks.items() if time-value['seen'] <= 1.0}
        used, result = set(), []
        # Keep tracking bounded on crowd shots. Only the largest three faces run DNNs.
        boxes = sorted(detections, key=lambda box: int(box[2])*int(box[3]), reverse=True)[:8]
        for rank, (x,y,w,h) in enumerate(boxes):
            box = [float(x/gray.shape[1]), float(y/gray.shape[0]), float(w/gray.shape[1]), float(h/gray.shape[0])]
            center = (box[0]+box[2]/2, box[1]+box[3]/2)
            matches=[]
            for key, track in self.tracks.items():
                if key in used:
                    continue
                old=track['box']
                distance=math.hypot(center[0]-old[0]-old[2]/2,center[1]-old[1]-old[3]/2)
                ratio=box[2]/max(old[2],1e-9)
                overlap=_iou(box,old)
                if .4 <= ratio <= 2.5 and (overlap >= .1 or distance <= .12):
                    matches.append((overlap-distance,key))
            if matches:
                key=max(matches)[1]
                track=self.tracks[key]
            else:
                key=self.next_id; self.next_id+=1
                track={'prediction':{'label':'unknown','confidence':0.,'intensity':0.},
                       'inferred':-math.inf,'confirmations':0,'mouth':None}
                self.tracks[key]=track
            mouth=cv2.resize(gray[y+h*2//3:y+h,x:x+w],(32,16))
            motion=0. if track['mouth'] is None else float(cv2.mean(cv2.absdiff(mouth,track['mouth']))[0]/255)
            track.update(box=box,seen=time,mouth=mouth)
            used.add(key)
            if self.recognizer is not None and rank<3 and time-track['inferred'] >= .95:
                fh,fw=frame.shape[:2]
                left=max(0,round((box[0]-.25*box[2])*fw))
                top=max(0,round((box[1]-.25*box[3])*fh))
                right=min(fw,round((box[0]+1.25*box[2])*fw))
                bottom=min(fh,round((box[1]+1.25*box[3])*fh))
                prediction=self.recognizer.predict(frame[top:bottom,left:right])
                strong=(prediction['label'] not in ('neutral','unknown')
                        and prediction['confidence']>=self.threshold and prediction['intensity']>=self.threshold)
                # Confirm using independent inference observations, not repeated cached samples.
                if time-track['inferred']>1.5:
                    track['confirmations']=0
                track['confirmations']=track['confirmations']+1 if strong else 0
                track.update(prediction=prediction,inferred=time)
            prediction=track['prediction']
            fresh=time-track['inferred'] <= 1.25
            peak=bool(fresh and track['confirmations']>=2)
            result.append({'track_id':key,'box':box,'mouth_motion':motion,
                           'speaking':bool(level>audio_gate and motion>.018),
                           'expression_label':prediction['label'] if fresh else 'unknown',
                           'expression_confidence':float(prediction['confidence']) if fresh else 0.,
                           'expression_score':float(prediction['intensity']) if fresh else 0.,
                           'expression_peak':peak})
        return result
