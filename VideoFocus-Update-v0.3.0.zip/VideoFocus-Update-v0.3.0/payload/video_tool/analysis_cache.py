"""Bounded, local cache of analysis metadata; no video, images or audio are stored.

The first run hashes and analyzes a source. Later runs can reuse its decisions
when content, algorithm and analysis options match, including across filenames.
Cache access is optional: a corrupt/unwritable cache never prevents analysis.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import os
import re
import tempfile
from pathlib import Path
from typing import Callable

CACHE_SCHEMA_VERSION = 1
CACHE_ALGORITHM_VERSION = 'video-focus-analysis-v2'
MAX_CACHE_BYTES = 128 * 1024 * 1024
MAX_ENTRY_BYTES = 8 * 1024 * 1024
MAX_SAMPLES = 200_000
_ENTRY_NAME = re.compile(r'^[0-9a-f]{64}\.json$')


def default_cache_directory() -> Path:
    """Keep the cache outside both the portable application and result folders."""
    if os.name == 'nt' and os.environ.get('LOCALAPPDATA'):
        return Path(os.environ['LOCALAPPDATA']) / 'VideoFocus' / 'AnalysisCache'
    base = Path(os.environ['XDG_CACHE_HOME']) if os.environ.get('XDG_CACHE_HOME') else Path.home() / '.cache'
    return base / 'VideoFocus' / 'AnalysisCache'


def _snapshot(source: Path) -> tuple[int, int, int]:
    stat = source.stat()
    return stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def _key(source: Path, options: dict) -> tuple[str, tuple[int, int, int]]:
    before = _snapshot(source)
    content = hashlib.sha256()
    with source.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            content.update(block)
    if _snapshot(source) != before:
        raise OSError('Source changed while its cache fingerprint was computed')
    identity = {'schema': CACHE_SCHEMA_VERSION, 'algorithm': CACHE_ALGORITHM_VERSION,
                'content_sha256': content.hexdigest(), 'options': options}
    encoded = json.dumps(identity, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest(), before


def _finite(value) -> bool:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _integer(value, minimum=0) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= minimum


def _unit(value) -> bool:
    return _finite(value) and 0 <= value <= 1


def _normalized_box(box) -> bool:
    if not isinstance(box, list) or len(box) != 4 or not all(_unit(value) for value in box):
        return False
    x, y, width, height = box
    return width > 0 and height > 0 and x + width <= 1 + 1e-9 and y + height <= 1 + 1e-9


def _valid_expression_report(report, duration, samples) -> bool:
    """Check every field consumed by the face camera before accepting a hit."""
    fps = report['info'].get('fps')
    if not _finite(fps) or not 1 <= fps <= 240:
        return False
    model = report.get('expression_model')
    if model is not None:
        fingerprint = model.get('fingerprint') if isinstance(model, dict) else None
        if not isinstance(fingerprint, str) or re.fullmatch(r'[0-9a-fA-F]{64}', fingerprint) is None:
            return False

    subjects = set()
    for sample in samples:
        cut_time = sample.get('cut_time', sample['time'])
        if (not isinstance(sample.get('cut'), bool) or not _finite(cut_time)
                or not 0 <= cut_time <= sample['time']):
            return False
        faces = sample.get('faces')
        if not isinstance(faces, list) or len(faces) > 8:
            return False
        current = {}
        for face in faces:
            if not isinstance(face, dict):
                return False
            subject = face.get('track_id')
            if not _integer(subject, 1) or subject in current or not _normalized_box(face.get('box')):
                return False
            if not all(_unit(face.get(field)) for field in ('expression_score', 'expression_confidence')):
                return False
            if (not all(isinstance(face.get(field), bool) for field in ('expression_peak', 'speaking'))
                    or not _finite(face.get('mouth_motion'))):
                return False
            current[subject] = face
        subjects.update(current)
        selected = sample.get('face_id')
        if selected is None:
            if sample.get('face_box') is not None:
                return False
        elif (not _integer(selected, 1) or selected not in current
              or sample.get('face_box') != current[selected]['box']):
            return False
        if not isinstance(sample.get('expression_peak'), bool) or not _unit(sample.get('expression_score')):
            return False

    events = report.get('emphasis_events')
    if not isinstance(events, list) or len(events) > MAX_SAMPLES:
        return False
    previous_end = 0.0
    identifiers = set()
    for event in events:
        if not isinstance(event, dict):
            return False
        identifier, subject = event.get('id'), event.get('subject_id')
        if (not _integer(identifier) or identifier in identifiers
                or not _integer(subject, 1) or subject not in subjects):
            return False
        times = [event.get(field) for field in ('shot_start', 'start', 'in_end', 'hold_end', 'end', 'shot_end')]
        if not all(_finite(value) for value in times):
            return False
        shot_start, start, in_end, hold_end, end, shot_end = times
        if not 0 <= shot_start <= start < in_end <= hold_end < end <= shot_end <= duration:
            return False
        if (start < previous_end or hold_end - in_end < 5 - 1e-6
                or not _integer(event.get('hold_frames'), math.ceil(5 * fps - 1e-7))):
            return False
        if not _normalized_box(event.get('face_box')) or not _unit(event.get('score')):
            return False
        identifiers.add(identifier)
        previous_end = end
    return True


def _valid_report(report) -> bool:
    if not isinstance(report, dict) or not isinstance(report.get('info'), dict):
        return False
    duration = report['info'].get('duration')
    if not _finite(duration) or duration <= 0:
        return False
    samples = report.get('samples')
    if not isinstance(samples, list) or not 0 < len(samples) <= MAX_SAMPLES:
        return False
    previous_time = -1.0
    for sample in samples:
        if not isinstance(sample, dict):
            return False
        timestamp = sample.get('time')
        if not _finite(timestamp) or not previous_time <= timestamp <= duration + 1 or timestamp < 0:
            return False
        if any(not _finite(sample.get(axis)) or not 0 <= sample[axis] <= 1 for axis in ('x', 'y')):
            return False
        if any(not isinstance(sample.get(flag), bool) for flag in ('focus', 'highlight')):
            return False
        previous_time = timestamp
    version = report.get('analysis_version')
    if version is not None and not isinstance(version, str):
        return False
    if isinstance(version, str) and version.startswith('expression-closeup-'):
        return _valid_expression_report(report, duration, samples)
    return True


def _reject_json_constant(value):
    raise ValueError(f'Invalid JSON numeric constant: {value}')


def _read_entry(path: Path, key: str):
    if path.is_symlink() or path.stat().st_size > min(MAX_ENTRY_BYTES, MAX_CACHE_BYTES):
        return None
    entry = json.loads(path.read_text(encoding='utf-8'), parse_constant=_reject_json_constant)
    if (not isinstance(entry, dict) or entry.get('schema') != CACHE_SCHEMA_VERSION
            or entry.get('algorithm') != CACHE_ALGORITHM_VERSION or entry.get('key') != key):
        return None
    report = entry.get('report')
    return report if _valid_report(report) else None


def _prune(directory: Path) -> None:
    """Best-effort LRU eviction. Restrict deletion to this cache's entry names."""
    entries = []
    for path in directory.iterdir():
        if not _ENTRY_NAME.fullmatch(path.name) or path.is_symlink():
            continue
        try:
            stat = path.stat()
            if path.is_file():
                entries.append((stat.st_mtime_ns, path, stat.st_size))
        except OSError:
            continue
    total = sum(size for _, _, size in entries)
    for _, path, size in sorted(entries, key=lambda entry: (entry[0], entry[1].name)):
        if total <= MAX_CACHE_BYTES:
            break
        try:
            path.unlink()
            total -= size
        except OSError:
            continue


def _save_entry(directory: Path, key: str, report: dict) -> None:
    if not _valid_report(report):
        return
    persisted = copy.deepcopy(report)
    persisted.pop('cache_hit', None)
    entry = {'schema': CACHE_SCHEMA_VERSION, 'algorithm': CACHE_ALGORITHM_VERSION,
             'key': key, 'report': persisted}
    encoded = json.dumps(entry, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if len(encoded) > min(MAX_ENTRY_BYTES, MAX_CACHE_BYTES):
        return
    directory.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix='.entry-', suffix='.tmp', dir=directory, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(encoded)
        os.replace(temporary, directory / f'{key}.json')
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    _prune(directory)


def _write_output(directory: Path, report: dict) -> None:
    # The result file is part of the job output, rather than the optional cache.
    (directory / 'analysis.json').write_text(json.dumps(report, ensure_ascii=False, allow_nan=False), encoding='utf-8')


def cached_analysis(source: Path, directory: Path, compute: Callable[[], dict], options: dict,
                    cache_dir: Path | None = None, progress: Callable[[float, str], None] = lambda *_: None) -> dict:
    """Return fresh/reused analysis, preserving the current job's report output.

    Only errors from the optional cache are ignored. The original compute
    exception and failures writing the job's own analysis.json remain visible.
    Callers should include every analysis-affecting option in ``options``.
    """
    source, directory = Path(source), Path(directory)
    key = source_snapshot = cache_root = cached = None
    progress(.01, 'Đang kiểm tra dữ liệu phân tích đã lưu')
    try:
        cache_root = Path(cache_dir) if cache_dir is not None else default_cache_directory()
        key, source_snapshot = _key(source, options)
        path = cache_root / f'{key}.json'
        try:
            cached = _read_entry(path, key)
        except (OSError, ValueError, TypeError, RecursionError):
            cached = None
        if cached is not None and _snapshot(source) == source_snapshot:
            try:
                os.utime(path, None)
                _prune(cache_root)
            except OSError:
                pass
        else:
            cached = None
    except (OSError, ValueError, TypeError, RecursionError):
        # The decoder may still be able to read a file whose hash/options could
        # not be cached; do not turn optional cache access into a job failure.
        key = source_snapshot = cached = None
    if cached is not None:
        report = copy.deepcopy(cached)
        report['cache_hit'] = True
        _write_output(directory, report)
        progress(.4, 'Dùng lại dữ liệu phân tích đã lưu')
        return report
    report = copy.deepcopy(compute())
    report['cache_hit'] = False
    _write_output(directory, report)
    if key is not None:
        try:
            if _snapshot(source) == source_snapshot:
                _save_entry(cache_root, key, report)
        except (OSError, ValueError, TypeError, RecursionError):
            pass
    return report
