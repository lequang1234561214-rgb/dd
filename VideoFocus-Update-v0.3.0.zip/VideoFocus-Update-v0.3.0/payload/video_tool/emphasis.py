"""Expression-driven close-up timing, independent of video decoding and rendering.

The planner deliberately looks ahead to shot boundaries: an emphasis is omitted
when there is no room for its complete entrance, five-second hold, and exit.
Face tracking and interpolation of the actual crop are renderer responsibilities.
"""

import math


_FRAME_MARGIN = 0.1
_CONFIRM_SECONDS = 0.25


def _number(value, fallback=None):
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError):
        return fallback
    return value if math.isfinite(value) else fallback


def _face(sample):
    subject = sample.get("face_id")
    box = sample.get("face_box")
    if subject is None or isinstance(subject, bool) or not isinstance(subject, int):
        return None
    if not isinstance(box, (list, tuple)) or len(box) != 4:
        return None
    box = [_number(component) for component in box]
    if any(component is None for component in box):
        return None
    x, y, width, height = box
    if (x < 0 or y < 0 or width <= 0 or height <= 0
            or x + width > 1.000001 or y + height > 1.000001):
        return None
    return subject, box


def plan_emphasis(samples, duration, *, enabled=True, min_hold=5.0,
                  zoom_in=0.8, zoom_out=0.8, cooldown=2.0):
    """Return deterministic, subject-locked close-up events without changing samples.

    Only consecutive expression peaks for a detected face confirm an entrance.
    ``min_hold`` cannot lower the five-second comfort minimum. Repeated peaks for
    the locked subject extend the plateau, up to the shot's reserved outro. Once
    the outro has begun it always completes, followed by ``cooldown`` before new
    confirmation can begin. Times are seconds, independent of source frame rate.
    """
    if not enabled:
        return []
    duration = _number(duration)
    min_hold = _number(min_hold)
    zoom_in = _number(zoom_in)
    zoom_out = _number(zoom_out)
    cooldown = _number(cooldown)
    if duration is None or duration <= 0:
        return []
    if (min_hold is None or zoom_in is None or zoom_out is None
            or cooldown is None or zoom_in <= 0 or zoom_out <= 0 or cooldown < 0):
        raise ValueError("Hold, zoom ramps and cooldown must be finite; ramps must be positive.")
    min_hold = max(5.0, min_hold)

    # Sort a new list, preserving even samples without faces: they can mark cuts
    # or interrupt confirmation. Ignore invalid timestamps, not valid cut markers.
    timed = []
    for sample in samples:
        if not isinstance(sample, dict):
            continue
        time = _number(sample.get("time"))
        if time is not None and 0 <= time < duration:
            timed.append((time, sample))
    timed.sort(key=lambda item: item[0])
    cuts = set()
    for time, sample in timed:
        if sample.get("cut", False):
            # Analysis detects cuts on sampled frames. A renderer may reserve the
            # preceding sample's time, so the final ramp cannot straddle the
            # unknown exact cut between those frames.
            boundary = _number(sample.get("cut_time"), time)
            if boundary < 0 or boundary > time:
                boundary = time
            if boundary > 0:
                cuts.add(boundary)
    boundaries = [0.0] + sorted(cuts) + [duration]

    events = []
    shot = 0
    candidate_id = None
    candidate_start = 0.0
    candidate_count = 0
    candidate_score = 0.0

    for time, sample in timed:
        while time >= boundaries[shot + 1]:
            shot += 1
            candidate_id, candidate_count = None, 0
        face = _face(sample)
        peak = bool(sample.get("expression_peak", False)) and face is not None
        score = min(1.0, max(0.0, _number(sample.get("expression_score"), 0.0)))
        previous = events[-1] if events else None

        if previous is not None and time < previous["end"]:
            # Never replace a locked subject, even if another face scores higher.
            if peak and face[0] == previous["subject_id"]:
                previous["score"] = max(previous["score"], score)
                if time <= previous["hold_end"]:
                    latest_hold_end = previous["shot_end"] - _FRAME_MARGIN - zoom_out
                    previous["hold_end"] = min(latest_hold_end,
                                               max(previous["hold_end"], time + min_hold))
                    previous["end"] = previous["hold_end"] + zoom_out
            candidate_id, candidate_count = None, 0
            continue
        if previous is not None and time < previous["end"] + cooldown:
            candidate_id, candidate_count = None, 0
            continue
        if not peak:
            candidate_id, candidate_count = None, 0
            continue

        if face[0] != candidate_id:
            candidate_id, candidate_start, candidate_count = face[0], time, 1
            candidate_score = score
        else:
            candidate_count += 1
            candidate_score = max(candidate_score, score)
        if candidate_count < 2 or time - candidate_start < _CONFIRM_SECONDS - 1e-9:
            continue

        in_end = time + zoom_in
        hold_end = in_end + min_hold
        end = hold_end + zoom_out
        if end > boundaries[shot + 1] - _FRAME_MARGIN:
            continue
        events.append({
            "id": len(events), "subject_id": face[0], "start": time,
            "in_end": in_end, "hold_end": hold_end, "end": end,
            "shot_start": boundaries[shot], "shot_end": boundaries[shot + 1],
            "face_box": list(face[1]), "score": candidate_score,
        })
        candidate_id, candidate_count = None, 0
    return events


def envelope(event, time):
    """Smoothstep zoom strength: exactly one for the complete locked hold."""
    time = _number(time)
    if time is None or time <= event["start"] or time >= event["end"]:
        return 0.0
    if time < event["in_end"]:
        progress = (time - event["start"]) / (event["in_end"] - event["start"])
    elif time <= event["hold_end"]:
        return 1.0
    else:
        progress = (event["end"] - time) / (event["end"] - event["hold_end"])
    progress = max(0.0, min(1.0, progress))
    return progress * progress * (3.0 - 2.0 * progress)
