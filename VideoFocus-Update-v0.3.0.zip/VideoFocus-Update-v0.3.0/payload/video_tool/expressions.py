"""Small, offline facial-expression classifier with landmark alignment.

Expression classes describe visible facial appearance. Their model probabilities
do not establish a person's feelings or the narrative importance of a scene.

Preprocessing and the alignment template follow OpenCV Zoo's Progressive Teacher
implementation. Copyright (C) 2022, Shenzhen Institute of Artificial Intelligence
and Robotics for Society. See models/LICENSE-expression-Apache-2.0.txt.
This integration adds input validation, bounded inference and Unicode path loading.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import threading

import cv2
import numpy as np


LABELS = ('angry', 'disgust', 'fearful', 'happy', 'neutral', 'sad', 'surprised')
SCHEMA_VERSION = 'aligned-mobilefacenet-expression-1'
MODEL_DIRECTORY = Path(__file__).resolve().parent.parent / 'models'
EXPRESSION_MODEL = 'facial_expression_recognition_mobilefacenet_2022july.onnx'
LANDMARK_MODEL = 'face_detection_yunet_2023mar.onnx'
MODEL_SHA256 = '4f61307602fc089ce20488a31d4e4614e3c9753a7d6c41578c854858b183e1a9'
LANDMARK_SHA256 = '8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4'
UPSTREAM_REVISION = '48b10fa505aeb51fbd127fc60a5c660040e823b7'
_MODEL_SPECS = {
    'expression': {'filename': EXPRESSION_MODEL, 'sha256': MODEL_SHA256,
                   'size_bytes': 4791892, 'license': 'Apache-2.0'},
    'landmarks': {'filename': LANDMARK_MODEL, 'sha256': LANDMARK_SHA256,
                  'size_bytes': 232589, 'license': 'MIT'},
}
_IDENTITY = {
    'schema_version': SCHEMA_VERSION,
    'models': _MODEL_SPECS,
    'input': 'BGR uint8 face crop; YuNet 5-point alignment; RGB 112; (pixel/255-.5)/.5',
    'postprocess': 'softmax 7; intensity=max non-neutral posterior; unknown=zero',
    'labels': LABELS,
}
MODEL_FINGERPRINT = hashlib.sha256(
    json.dumps(_IDENTITY, sort_keys=True, separators=(',', ':')).encode('utf-8')
).hexdigest()
_STANDARD_POINTS = np.array([
    [38.2946, 51.6963], [73.5318, 51.5014], [56.0252, 71.7366],
    [41.5493, 92.3655], [70.7299, 92.2041],
], dtype=np.float64)


def model_metadata():
    """Return stable model and preprocessing identity for analysis-cache keys."""
    result = deepcopy(_IDENTITY)
    result.update({'fingerprint': MODEL_FINGERPRINT,
                   'upstream_repository': 'https://github.com/opencv/opencv_zoo',
                   'upstream_revision': UPSTREAM_REVISION})
    return result


def _model_buffer(path, expected_sha256, expected_size):
    try:
        contents = Path(path).read_bytes()
    except OSError as exc:
        raise RuntimeError(
            f'Không đọc được mô hình biểu cảm: {path}. '
            'Hãy cài đầy đủ thư mục models đi kèm ứng dụng.'
        ) from exc
    if len(contents) != expected_size or hashlib.sha256(contents).hexdigest() != expected_sha256:
        raise RuntimeError(f'Mô hình sai phiên bản hoặc bị hỏng (SHA256 không khớp): {path}')
    # File I/O is handled by pathlib/Python: OpenCV never opens a Unicode path.
    return np.frombuffer(contents, dtype=np.uint8)


def _unknown():
    # Zeroes deliberately mean "no observation", not a classifier posterior.
    return {'label': 'unknown', 'confidence': 0.0,
            'probabilities': {label: 0.0 for label in LABELS}, 'intensity': 0.0}


def _postprocess(logits):
    values = np.asarray(logits, dtype=np.float64).reshape(-1)
    if values.size != len(LABELS) or not np.isfinite(values).all():
        raise RuntimeError('Mô hình biểu cảm trả về dữ liệu không hợp lệ.')
    # Stable softmax is necessary: the upstream layer named "label" holds logits.
    weights = np.exp(values - np.max(values))
    probabilities = weights / weights.sum()
    index = int(np.argmax(probabilities))
    return {'label': LABELS[index], 'confidence': float(probabilities[index]),
            'probabilities': dict(zip(LABELS, map(float, probabilities))),
            # This is classifier evidence for a non-neutral appearance, not a
            # physical measurement of emotion intensity.
            'intensity': float(max(probabilities[i] for i, label in enumerate(LABELS)
                                   if label != 'neutral'))}


def _align(image, landmarks):
    points = np.asarray(landmarks, dtype=np.float64).reshape(5, 2)
    if not np.isfinite(points).all():
        return None
    # Least-squares non-reflective similarity transform, matching Zoo's template.
    x, y = points[:, 0], points[:, 1]
    ones, zeros = np.ones(5), np.zeros(5)
    matrix = np.vstack((np.column_stack((x, -y, ones, zeros)),
                        np.column_stack((y, x, zeros, ones))))
    target = np.concatenate((_STANDARD_POINTS[:, 0], _STANDARD_POINTS[:, 1]))
    coefficients, _, rank, _ = np.linalg.lstsq(matrix, target, rcond=None)
    if rank < 4 or not np.isfinite(coefficients).all():
        return None
    a, b, tx, ty = coefficients
    if a * a + b * b < 1e-8:
        return None
    transform = np.array([[a, -b, tx], [b, a, ty]], dtype=np.float64)
    return cv2.warpAffine(image, transform, (112, 112), flags=cv2.INTER_LINEAR)


class ExpressionRecognizer:
    """Run two small CPU DNNs; caller controls sample rate and global thread cap.

    Pass one BGR uint8 face crop with approximately 25% surrounding margin. The
    crop is bounded to 320px before YuNet locates five landmarks. Crops without a
    reliable face return ``unknown`` and zero evidence. Invalid inputs and missing
    or corrupt models raise clear errors. A single instance serializes inference.
    """

    def __init__(self, model_directory=None):
        directory = Path(model_directory) if model_directory is not None else MODEL_DIRECTORY
        expression = _model_buffer(directory / EXPRESSION_MODEL, MODEL_SHA256, 4791892)
        landmarks = _model_buffer(directory / LANDMARK_MODEL, LANDMARK_SHA256, 232589)
        try:
            self._net = cv2.dnn.readNetFromONNX(expression)
            self._net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
            self._net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
            self._detector = cv2.FaceDetectorYN.create(
                'onnx', landmarks, np.empty(0, dtype=np.uint8), (320, 320),
                .7, .3, 20, cv2.dnn.DNN_BACKEND_OPENCV, cv2.dnn.DNN_TARGET_CPU)
        except cv2.error as exc:
            raise RuntimeError('Không khởi tạo được mô hình biểu cảm. Cần OpenCV 4.11 và models đầy đủ.') from exc
        self._lock = threading.Lock()

    @staticmethod
    def model_metadata():
        return model_metadata()

    def predict(self, face_bgr):
        if (not isinstance(face_bgr, np.ndarray) or face_bgr.ndim != 3
                or face_bgr.shape[2] != 3 or face_bgr.dtype != np.uint8
                or face_bgr.shape[0] == 0 or face_bgr.shape[1] == 0):
            raise ValueError('Ảnh khuôn mặt phải là mảng BGR uint8 không rỗng với 3 kênh.')
        height, width = face_bgr.shape[:2]
        if min(height, width) < 24:
            return _unknown()
        scale = min(320 / max(height, width), 160 / min(height, width))
        size = (max(1, round(width * scale)), max(1, round(height * scale)))
        image = cv2.resize(face_bgr, size, interpolation=(cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR))
        with self._lock:
            try:
                self._detector.setInputSize(size)
                _, faces = self._detector.detect(image)
                if faces is None or not len(faces):
                    return _unknown()
                # The caller provides one subject; prefer the largest face if a
                # second face enters the margin of that crop.
                face = max(faces, key=lambda row: float(row[2] * row[3]))
                if (not np.isfinite(face).all() or float(face[-1]) < .7
                        or face[2] < 12 or face[3] < 12):
                    return _unknown()
                aligned = _align(image, face[4:14])
                if aligned is None:
                    return _unknown()
                rgb = cv2.cvtColor(aligned, cv2.COLOR_BGR2RGB).astype(np.float32)
                rgb = (rgb / 255.0 - .5) / .5
                self._net.setInput(cv2.dnn.blobFromImage(rgb), 'data')
                return _postprocess(self._net.forward('label'))
            except cv2.error as exc:
                raise RuntimeError('Suy luận biểu cảm bằng OpenCV thất bại.') from exc
