"""Continuous face close-up camera with frame-exact holds and no zoom pulses."""
import math
import bisect

import cv2
import numpy as np

from .emphasis import envelope


def _box(sample, subject):
    for face in sample.get('faces', []):
        if face['track_id'] == subject:
            return face['box']
    return None


def prepare_events(events, samples, fps):
    """Quantize ramps/holds, reserve cuts and reject sustained subject loss."""
    result=[]
    for original in events:
        event=dict(original)
        start=max(0,math.ceil(event['start']*fps-1e-7))
        ramp_in=max(1,math.ceil((event['in_end']-event['start'])*fps-1e-7))
        ramp_out=max(1,math.ceil((event['end']-event['hold_end'])*fps-1e-7))
        in_end=start+ramp_in
        minimum_hold=math.ceil(5*fps-1e-7)
        latest_end=math.floor((event['shot_end']-.1)*fps+1e-7)
        hold_end=min(latest_end-ramp_out,max(in_end+minimum_hold,math.floor(event['hold_end']*fps+1e-7)))
        if hold_end-in_end < minimum_hold:
            continue
        event.update(start=start/fps,in_end=in_end/fps,hold_end=hold_end/fps,end=(hold_end+ramp_out)/fps)
        observations=[s for s in samples if event['start'] <= s['time'] <= event['hold_end']]
        visible=[s for s in observations if _box(s,event['subject_id']) is not None]
        if not observations or len(visible)/len(observations)<.8:
            continue
        seen=event['start']
        longest_gap=0.
        for sample in visible:
            longest_gap=max(longest_gap,sample['time']-seen)
            seen=sample['time']
        longest_gap=max(longest_gap,event['hold_end']-seen)
        if longest_gap>1.0:
            continue
        event['id']=len(result)
        event['hold_frames']=hold_end-in_end
        result.append(event)
    return result


def _clamp_view(scale,cx,cy,w,h,out_w,out_h):
    half_w=out_w/(2*scale*w)
    half_h=out_h/(2*scale*h)
    cx=.5 if half_w>=.5 else max(half_w,min(1-half_w,cx))
    cy=.5 if half_h>=.5 else max(half_h,min(1-half_h,cy))
    return {'scale':scale,'cx':cx,'cy':cy}


class Camera:
    def __init__(self, report, fps, width, height):
        self.samples=report['samples']
        self.events=report.get('emphasis_events',[])
        self.fps,self.width,self.height=fps,width,height
        self.alpha,self.center=0.,.5
        self.pointer=0
        self.active=None
        self.calm_until=-1.
        self.normal_target=0.
        self.normal_transition=None
        self.normal_locked_until=0.
        duration=report.get('info',{}).get('duration',self.samples[-1]['time']+.25)
        self.shot_boundaries=sorted({s.get('cut_time',s['time']) for s in self.samples if s.get('cut',False) and s.get('cut_time',s['time'])>0})+[duration]

    def _normal(self,w,h,alpha,center):
        fit=min(self.width/w,self.height/h)
        crop=max(self.width/w,self.height/h)
        scale=math.exp((1-alpha)*math.log(fit)+alpha*math.log(crop))
        return _clamp_view(scale,(1-alpha)*.5+alpha*center,.5,w,h,self.width,self.height)

    def _begin(self,event,index,w,h):
        self.active=event
        self.incoming=self._normal(w,h,self.alpha,self.center)
        future=min(self.samples,key=lambda s:abs(s['time']-event['end']))
        self.out_alpha=float(future['focus']) if w/h>9/16 else 0.
        self.out_center=future['x']
        self.outgoing=self._normal(w,h,self.out_alpha,self.out_center)
        boxes=[_box(s,event['subject_id']) for s in self.samples if event['start']<=s['time']<=event['end']]
        boxes=[box for box in boxes if box is not None] or [event['face_box']]
        # Use the largest known face in this whole event: zoom stays constant
        # during the hold instead of breathing when the detector's box changes.
        face_w=max(box[2] for box in boxes)*w
        face_h=max(box[3] for box in boxes)*h
        base_crop=max(self.width/w,self.height/h)
        close=min(self.width*.72/max(face_w,1),self.height*.42/max(face_h,1))
        self.close_scale=max(base_crop,min(base_crop*2.2,close))
        first=_box(self.samples[index],event['subject_id']) or event['face_box']
        self.follow_x=first[0]+first[2]/2
        self.follow_y=first[1]+first[3]/2
        self.last_box=first

    def view(self,time,index,w,h):
        while self.pointer<len(self.events) and time>=self.events[self.pointer]['end']:
            if self.active is not None:
                self.alpha,self.center=self.out_alpha,self.out_center
                self.calm_until=self.active['end']+5.
                self.normal_target=self.alpha
                self.normal_transition=None
                self.normal_locked_until=self.calm_until
                self.active=None
            self.pointer+=1
        event=self.events[self.pointer] if self.pointer<len(self.events) else None
        if event is not None and event['start']<=time<event['end']:
            if self.active is None:
                self._begin(event,index,w,h)
            box=_box(self.samples[index],event['subject_id'])
            if box is not None:
                self.last_box=box
                if index+1<len(self.samples):
                    following=self.samples[index+1]
                    next_box=_box(following,event['subject_id'])
                    if next_box is not None and not following.get('cut',False):
                        dt=following['time']-self.samples[index]['time']
                        fraction=min(1.,max(0.,(time-self.samples[index]['time'])/max(dt,1e-9)))
                        box=[a+(b-a)*fraction for a,b in zip(box,next_box)]
                target_x,target_y=box[0]+box[2]/2,box[1]+box[3]/2
                smooth=1-math.exp(-1/(self.fps*.35))
                for axis,target in [('follow_x',target_x),('follow_y',target_y)]:
                    old=getattr(self,axis)
                    delta=(target-old)*smooth
                    setattr(self,axis,old+max(-.2/self.fps,min(.2/self.fps,delta)))
            # Face center sits above the canvas center, leaving chin/shoulder room.
            close_y=self.follow_y+.12*(self.height/self.close_scale)/h
            close=_clamp_view(self.close_scale,self.follow_x,close_y,w,h,self.width,self.height)
            strength=envelope(event,time)
            base=self.incoming if time<=event['hold_end'] else self.outgoing
            scale=math.exp((1-strength)*math.log(base['scale'])+strength*math.log(close['scale']))
            view=_clamp_view(scale,(1-strength)*base['cx']+strength*close['cx'],
                             (1-strength)*base['cy']+strength*close['cy'],w,h,self.width,self.height)
            view.update(emphasis=strength,event_id=event['id'])
            return view
        sample=self.samples[index]
        if sample.get('cut',False):
            self.alpha,self.center=0.,.5
            self.normal_target=0.
            self.normal_transition=None
            self.normal_locked_until=time
        if self.normal_transition is not None:
            transition=self.normal_transition
            progress=min(1.,max(0.,(time-transition['start'])/transition['duration']))
            eased=progress*progress*(3-2*progress)
            self.alpha=transition['from']+(transition['to']-transition['from'])*eased
            if progress>=1:
                self.alpha=transition['to']
                self.normal_locked_until=time+5.
                self.normal_transition=None
        if self.normal_transition is None and time>=max(self.calm_until,self.normal_locked_until):
            target=float(sample['focus']) if w/h>9/16 else 0.
            boundary_index=bisect.bisect_right(self.shot_boundaries,time)
            boundary=self.shot_boundaries[min(boundary_index,len(self.shot_boundaries)-1)]
            remaining=boundary-time
            # A new crop also needs its complete entrance and five-second hold;
            # brief shots stay wide, and an outro never starts just before a cut.
            enough_room=remaining>=1.1 and (target==0 or remaining>=6.1)
            if target!=self.normal_target and enough_room:
                self.normal_target=target
                self.normal_transition={'start':time,'from':self.alpha,'to':target,'duration':1.}
        if abs(sample['x']-self.center)>.04:
            delta=(sample['x']-self.center)*(1-math.exp(-1/self.fps))
            self.center+=max(-.12/self.fps,min(.12/self.fps,delta))
        view=self._normal(w,h,self.alpha,self.center)
        view.update(emphasis=0.,event_id=None)
        return view


def compose(frame,view,width,height):
    """A single geometric camera transform; never dissolve duplicate subjects."""
    h,w=frame.shape[:2]
    scale=view['scale']
    tx=width/2-view['cx']*w*scale
    ty=height/2-view['cy']*h*scale
    transform=np.array([[scale,0,tx],[0,scale,ty]],dtype=np.float32)
    fills=tx<=0 and ty<=0 and tx+w*scale>=width and ty+h*scale>=height
    if fills:
        return cv2.warpAffine(frame,transform,(width,height),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE)
    blur_w=min(180,width); blur_h=max(1,round(height*blur_w/width))
    small=cv2.resize(frame,(blur_w,blur_h),interpolation=cv2.INTER_AREA)
    small=cv2.GaussianBlur(small,(0,0),max(.5,20*blur_w/width))
    background=cv2.resize(small,(width,height))
    return cv2.warpAffine(frame,transform,(width,height),dst=background,flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_TRANSPARENT)
