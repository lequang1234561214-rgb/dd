"""Isolated portable desktop worker, with atomic progress for the Windows GUI."""
import argparse
import json
import os
import sys
import traceback
import time
import uuid
import tempfile
from pathlib import Path

# The portable folder contains its own Python and native binaries.
APP_ROOT = Path(__file__).resolve().parents[1]
os.environ['PATH'] = str(APP_ROOT/'tools') + os.pathsep + os.environ.get('PATH', '')

from video_tool.engine import ANALYSIS_VERSION, PROFILES, analyze, render
from video_tool.analysis_cache import cached_analysis
from video_tool.expressions import model_metadata


def write_status(path, **fields):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(fields, ensure_ascii=False), encoding='utf-8')
    for attempt in range(25):
        try:
            os.replace(temp, path)
            return
        except PermissionError:
            if attempt == 24:
                raise
            time.sleep(.02)


def execute(source, output_root, height, effects, sensitivity, status, *, profile='fast',
            encoder='nvenc', use_cache=True, cache_dir=None, emphasis=True):
    output_root.mkdir(parents=True, exist_ok=True)
    final_file = output_root / f'{source.stem[:60]}-{uuid.uuid4().hex[:8]}.mp4'
    def progress(value, message):
        write_status(status, state='running', progress=round(value*100), message=message, output=str(output_root))
    try:
        if profile not in PROFILES:
            raise ValueError('Chế độ xử lý không hợp lệ.')
        if profile == 'light':
            if os.name == 'nt':
                import ctypes
                ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x4000)
            elif hasattr(os, 'nice'):
                os.nice(5)
        # Scratch is on the output volume, so completion uses a rename instead of copying a large MP4.
        with tempfile.TemporaryDirectory(prefix='.videofocus-work-', dir=output_root) as temporary:
            directory = Path(temporary)
            try:
                progress(0, 'Đang chuẩn bị video')
                compute = lambda: analyze(source, directory, sensitivity, progress, profile=profile, emphasis=emphasis)
                if use_cache:
                    report = cached_analysis(source, directory, compute,
                                             {'sensitivity':sensitivity,'analysis_version':ANALYSIS_VERSION,
                                              'emphasis':bool(emphasis),
                                              'expression_model':model_metadata()['fingerprint'] if emphasis else None},
                                             cache_dir=cache_dir, progress=progress)
                else:
                    report = compute()
                    report['cache_hit'] = False
                render(source, directory, report, height, effects, progress, profile=profile,
                       encoder=encoder, export_images=False)
                encoding = json.loads((directory/'encoding.json').read_text(encoding='utf-8'))
                (directory/'output.mp4').replace(final_file)
            except Exception:
                # Keep useful encoder diagnostics internally, never in the user's video output folder.
                for name in ('encoder.log','audio-analysis.log','encoding.json'):
                    path=directory/name
                    if path.exists():
                        status.with_name(status.stem+'-'+name).write_bytes(path.read_bytes())
                raise
        actual = encoding['used']
        label = 'NVIDIA NVENC' if actual=='h264_nvenc' else 'CPU' if actual=='libx264' else actual
        if encoder!='cpu' and actual=='libx264':
            label += ' (GPU chưa sẵn sàng)'
        write_status(status, state='done', progress=100, message='Hoàn tất · '+label+(f' · {len(report.get("emphasis_events",[]))} đoạn cận' if emphasis else ''),
                     output=str(output_root), output_file=str(final_file), encoder=actual,
                     cache_hit=report.get('cache_hit',False), emphasis_count=len(report.get('emphasis_events',[])))
        return 0
    except Exception as exc:
        status.with_suffix('.error.log').write_text(traceback.format_exc(), encoding='utf-8')
        write_status(status, state='error', progress=0, message=str(exc)[-2000:], output=str(output_root))
        return 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--status', type=Path, required=True)
    parser.add_argument('--height', type=int, choices=[640,1280,1920], default=1280)
    parser.add_argument('--sensitivity', type=float, default=.5)
    parser.add_argument('--no-effects', action='store_true')
    parser.add_argument('--border', action='store_true', help='Optional border; no zoom')
    parser.add_argument('--profile', choices=list(PROFILES), default='fast')
    parser.add_argument('--encoder', choices=['cpu','auto','nvenc'], default='nvenc')
    parser.add_argument('--no-cache', action='store_true')
    parser.add_argument('--no-emphasis', action='store_true', help='Disable expression-led face close-ups')
    parser.add_argument('--cache-dir', type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    args.status.parent.mkdir(parents=True, exist_ok=True)
    if not 0 <= args.sensitivity <= 1:
        parser.error('sensitivity must be between 0 and 1')
    return execute(args.source, args.output, args.height, args.border and not args.no_effects, args.sensitivity, args.status,
                   profile=args.profile, encoder=args.encoder, use_cache=not args.no_cache, cache_dir=args.cache_dir,
                   emphasis=not args.no_emphasis)


if __name__ == '__main__':
    sys.exit(main())
