import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ['PATH'] = str(ROOT/'tools') + os.pathsep + os.environ.get('PATH','')
from video_tool.engine import analyze, probe, render, run
from video_tool.expressions import ExpressionRecognizer, _postprocess
from video_tool.emphasis import plan_emphasis
from video_tool.camera import prepare_events
import numpy as np


def main():
    print('Video Focus self-check', flush=True)
    print('Python:',sys.version,flush=True)
    print(run(['ffmpeg','-version']).decode(errors='replace').splitlines()[0],flush=True)
    recognizer=ExpressionRecognizer()
    recognizer._net.setInput(np.zeros((1,3,112,112),np.float32),'data')
    posterior=_postprocess(recognizer._net.forward('label'))
    assert abs(sum(posterior['probabilities'].values())-1)<1e-6
    print('Offline expression model + landmark weights loaded; DNN forward passed.',flush=True)
    with tempfile.TemporaryDirectory(prefix='VideoFocus-') as tmp:
        root=Path(tmp)
        source=root/'sample.mp4'
        run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=640x360:rate=12:duration=8',
             '-f','lavfi','-i','sine=frequency=440:duration=8','-c:v','libx264','-threads','2',
             '-pix_fmt','yuv420p','-c:a','aac','-shortest',str(source)])
        report=analyze(source,root)
        assert len(report['samples']) >= 6
        for sample in report['samples']:
            sample.update(focus=False,x=.5,highlight=True,face_id=1,face_box=[.4,.25,.2,.2],
                          expression_peak=True,expression_score=.9,faces=[{'track_id':1,'box':[.4,.25,.2,.2]}])
        report['emphasis_events']=prepare_events(plan_emphasis(report['samples'],report['info']['duration'],zoom_in=1.,zoom_out=1.),report['samples'],12)
        assert report['emphasis_events'] and all(e['hold_end']-e['in_end']>=5 for e in report['emphasis_events'])
        shots=render(source,root,report,encoder="nvenc",profile="fast")
        assert not shots and not list(root.glob('*.jpg'))
        import json
        print('Encoder selected:',json.loads((root/'encoding.json').read_text())['used'],flush=True)
        result=probe(root/'output.mp4')
        assert result['audio'] and abs(result['duration']-8)<.3
        metadata=run(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height','-of','csv=p=0',str(root/'output.mp4')])
        assert metadata.strip()==b'360,640',metadata
    print('PASS: face detector loaded; decoding, crop, synthetic >=5s close-up, no screenshots, H.264, AAC and 9:16 output work.',flush=True)


if __name__=='__main__':
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        sys.exit(1)
