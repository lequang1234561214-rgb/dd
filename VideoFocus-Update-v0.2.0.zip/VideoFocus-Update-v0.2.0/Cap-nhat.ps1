﻿param([string]$Target, [switch]$PrepareOnly)
$ErrorActionPreference='Stop'

function Relative-Path([string]$relative) {
    return $relative.Replace('\','/')
}
function File-Digest([string]$path) {
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
}

try {
    if([string]::IsNullOrWhiteSpace($Target)) {
        if($PrepareOnly) { throw 'Specify -Target when using -PrepareOnly.' }
        Add-Type -AssemblyName System.Windows.Forms
        [Windows.Forms.Application]::EnableVisualStyles()
        $dialog=New-Object Windows.Forms.FolderBrowserDialog
        $dialog.Description='Đóng Video Focus, rồi chọn thư mục ứng dụng có runtime, tools và VideoFocus.ps1.'
        $dialog.ShowNewFolderButton=$false
        try {
            if($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { exit 0 }
            $Target=$dialog.SelectedPath
        } finally { $dialog.Dispose() }
    }
    $targetRoot=[IO.Path]::GetFullPath($Target)
    if(!(Test-Path -LiteralPath $targetRoot -PathType Container)) { throw 'Thư mục ứng dụng không tồn tại.' }
    foreach($required in @('runtime/python.exe','tools/ffmpeg.exe','tools/ffprobe.exe','VideoFocus.ps1')) {
        if(!(Test-Path -LiteralPath (Join-Path $targetRoot $required) -PathType Leaf)) {
            throw "Không tìm thấy $required. Hãy chọn đúng thư mục VideoFocus-Windows-x64 đã giải nén."
        }
    }
    Write-Host 'Hãy bảo đảm Video Focus đã đóng trước khi cập nhật.'
    $manifestPath=Join-Path $PSScriptRoot 'update-manifest.json'
    $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if($manifest.version -ne '0.2.0') { throw 'Phiên bản gói cập nhật không phù hợp.' }
    $allowed=@('video_tool/engine.py','video_tool/windows_worker.py','video_tool/analysis_cache.py',
               'VideoFocus.ps1','selfcheck.py','HUONG-DAN.txt','VALIDATION-v0.2.txt')
    $requiredPayload=@('video_tool/engine.py','video_tool/windows_worker.py','video_tool/analysis_cache.py',
                       'VideoFocus.ps1','selfcheck.py','HUONG-DAN.txt')
    $seen=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $entries=New-Object System.Collections.ArrayList
    foreach($entry in @($manifest.files)) {
        $relative=Relative-Path ([string]$entry.path)
        if($relative -notin $allowed -or !$seen.Add($relative)) { throw "Đường dẫn cập nhật không hợp lệ hoặc bị trùng: $relative" }
        if([string]$entry.sha256 -notmatch '^[0-9a-f]{64}$') { throw "Checksum không hợp lệ: $relative" }
        $payload=Join-Path (Join-Path $PSScriptRoot 'payload') $relative
        if(!(Test-Path -LiteralPath $payload -PathType Leaf)) { throw "Thiếu tệp cập nhật: $relative" }
        if((Get-Item -LiteralPath $payload).Length -ne [long]$entry.size) { throw "Kích thước tệp không đúng: $relative" }
        if((File-Digest $payload) -ne $entry.sha256) { throw "Checksum không khớp: $relative" }
        $destination=Join-Path $targetRoot $relative
        if(Test-Path -LiteralPath $destination -PathType Container) { throw "Đích cập nhật là một thư mục: $relative" }
        [void]$entries.Add([pscustomobject]@{ Relative=$relative; Payload=$payload; Destination=$destination; Sha256=$entry.sha256; Existed=(Test-Path -LiteralPath $destination -PathType Leaf) })
    }
    foreach($required in $requiredPayload) {
        if(!$seen.Contains($required)) { throw "Thiếu mục bắt buộc trong danh sách cập nhật: $required" }
    }
    # Verify every payload file before creating backups or replacing any application file.
    $backupRoot=Join-Path (Join-Path $targetRoot 'VideoFocus-backups') ([Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($backupRoot)
    foreach($entry in $entries) {
        if($entry.Existed) {
            $backup=Join-Path $backupRoot $entry.Relative
            [void][IO.Directory]::CreateDirectory((Split-Path $backup -Parent))
            Copy-Item -LiteralPath $entry.Destination -Destination $backup
        }
    }
    $journal=@($entries | ForEach-Object { [pscustomobject]@{ Path=$_.Relative; Existed=$_.Existed } })
    [pscustomobject]@{ Version='0.2.0'; CreatedUtc=[DateTime]::UtcNow.ToString('o'); Files=$journal } |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $backupRoot 'backup-manifest.json') -Encoding UTF8
    $attempted=New-Object System.Collections.ArrayList
    $temporaries=New-Object System.Collections.ArrayList
    try {
        foreach($entry in $entries) {
            [void][IO.Directory]::CreateDirectory((Split-Path $entry.Destination -Parent))
            $temporary=$entry.Destination+'.videofocus-new-'+[Guid]::NewGuid().ToString('N')
            [void]$temporaries.Add($temporary)
            Copy-Item -LiteralPath $entry.Payload -Destination $temporary
            if((File-Digest $temporary) -ne $entry.Sha256) { throw "Kiểm tra tệp tạm thất bại: $($entry.Relative)" }
            [void]$attempted.Add($entry)
            Move-Item -LiteralPath $temporary -Destination $entry.Destination -Force
            Write-Host "Đã cập nhật $($entry.Relative)"
        }
        foreach($entry in $entries) {
            if((File-Digest $entry.Destination) -ne $entry.Sha256) { throw "Kiểm tra sau cập nhật thất bại: $($entry.Relative)" }
        }
    } catch {
        $installError=$_.Exception.Message
        $rollbackErrors=New-Object System.Collections.ArrayList
        for($index=$attempted.Count-1; $index -ge 0; $index--) {
            $entry=$attempted[$index]
            try {
                if($entry.Existed) {
                    Copy-Item -LiteralPath (Join-Path $backupRoot $entry.Relative) -Destination $entry.Destination -Force
                } elseif(Test-Path -LiteralPath $entry.Destination -PathType Leaf) {
                    Remove-Item -LiteralPath $entry.Destination
                }
            } catch { [void]$rollbackErrors.Add($_.Exception.Message) }
        }
        if($rollbackErrors.Count) {
            throw "Cập nhật thất bại: $installError. Có lỗi khôi phục; bản sao gốc tại $backupRoot. $($rollbackErrors -join '; ')"
        }
        throw "Cập nhật thất bại và đã khôi phục các tệp cũ: $installError. Bản sao tại $backupRoot"
    } finally {
        foreach($temporary in $temporaries) {
            if(Test-Path -LiteralPath $temporary -PathType Leaf) { Remove-Item -LiteralPath $temporary -ErrorAction SilentlyContinue }
        }
    }
    Write-Host "Cập nhật thành công. Bản sao các tệp cũ: $backupRoot"
    if(!$PrepareOnly) {
        $launcher=Join-Path $targetRoot 'VideoFocus.ps1'
        $arguments='-NoLogo -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$launcher+'"'
        Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -WorkingDirectory $targetRoot | Out-Null
    }
    exit 0
} catch {
    Write-Host ('LỖI: '+$_.Exception.Message) -ForegroundColor Red
    exit 1
}
