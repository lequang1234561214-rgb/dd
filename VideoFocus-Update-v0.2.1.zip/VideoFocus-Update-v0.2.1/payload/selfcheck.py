import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ['PATH'] = str(ROOT/'tools') + os.pathsep + os.environ.get('PATH','')
from video_tool.engine import analyze, probe, render, run


def main():
    print('Video Focus self-check', flush=True)
    print('Python:',sys.version,flush=True)
    print(run(['ffmpeg','-version']).decode(errors='replace').splitlines()[0],flush=True)
    with tempfile.TemporaryDirectory(prefix='VideoFocus-') as tmp:
        root=Path(tmp)
        source=root/'sample.mp4'
        run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=640x360:rate=12:duration=2',
             '-f','lavfi','-i','sine=frequency=440:duration=2','-c:v','libx264','-threads','2',
             '-pix_fmt','yuv420p','-c:a','aac','-shortest',str(source)])
        report=analyze(source,root)
        assert len(report['samples']) >= 6
        for sample in report['samples']:
            sample.update(focus=True,x=.6,highlight=True)
        shots=render(source,root,report,encoder="nvenc",profile="fast")
        assert not shots and not list(root.glob('*.jpg'))
        import json
        print('Encoder selected:',json.loads((root/'encoding.json').read_text())['used'],flush=True)
        result=probe(root/'output.mp4')
        assert result['audio'] and abs(result['duration']-2)<.3
        metadata=run(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height','-of','csv=p=0',str(root/'output.mp4')])
        assert metadata.strip()==b'360,640',metadata
    print('PASS: face detector loaded; decoding, crop, stable crop, no screenshots, H.264, AAC and 9:16 output work.',flush=True)


if __name__=='__main__':
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        sys.exit(1)
