﻿# Windows PowerShell 5.1 / Windows Forms. No server and no Python installation required.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$script:Root = $PSScriptRoot
$script:Jobs = New-Object System.Collections.ArrayList
$script:Running = $false
$script:Cancelled = $false
$script:JobRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'VideoFocus\Jobs'
New-Item -ItemType Directory -Force -Path $script:JobRoot | Out-Null
$script:CacheRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'VideoFocus\AnalysisCache'

function Info([string]$text) {
    [System.Windows.Forms.MessageBox]::Show($text, 'Video Focus', 'OK', 'Information') | Out-Null
}
function Quote([string]$value) {
    # Windows paths cannot contain quotes. Double trailing backslashes before the closing quote.
    return '"' + ($value -replace '(\\+)$', '$1$1') + '"'
}
function Resolve-UiChoice($control, [object[]]$values, [int]$defaultIndex) {
    if($null -eq $control -or $null -eq $control.PSObject.Properties['SelectedIndex']) {
        throw 'Ô lựa chọn chưa sẵn sàng. Hãy đóng rồi mở lại ứng dụng.'
    }
    $index=$control.SelectedIndex
    if($null -eq $index -or [int]$index -lt 0 -or [int]$index -ge $values.Count) {
        $index=$defaultIndex
        $control.SelectedIndex=$index
    }
    return $values[[int]$index]
}
function Report-UiError($record) {
    $log=Join-Path $script:JobRoot ('ui-error-'+[Guid]::NewGuid().ToString('N')+'.log')
    try {
        (($record | Format-List * -Force | Out-String)+[Environment]::NewLine+$record.ScriptStackTrace) |
            Set-Content -LiteralPath $log -Encoding UTF8
    } catch {}
    Info ('Giao diện gặp lỗi: '+$record.Exception.Message+"`nNhật ký: "+$log)
}
function Set-Controls([bool]$enabled) {
    foreach ($control in @($add,$clear,$choose,$out,$resolution,$parallel,$effects,$sensitivity,$uiProfile,$uiEncoder,$uiUseCache,$library,$start)) {
        $control.Enabled = $enabled
    }
    $cancel.Enabled = !$enabled
}
function Add-Videos($paths) {
    if ($script:Running) { return }
    foreach ($path in $paths) {
        if (!(Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        if (@($script:Jobs | Where-Object { $_.Source -eq $path }).Count -gt 0) { continue }
        $row = $grid.Rows.Add([IO.Path]::GetFileName($path), '0%', 'Sẵn sàng')
        [void]$script:Jobs.Add([pscustomobject]@{
            Source = $path; Row = $row; State = 'ready'; Process = $null; StatusFile = ''; Output = ''; LogFile = ''
        })
    }
    $summary.Text = "$($script:Jobs.Count) video đã chọn"
}
function Launch-Next {
    if (!$script:Running -or $script:Cancelled) { return }
    $active = @($script:Jobs | Where-Object { $_.State -eq 'running' }).Count
    foreach ($job in $script:Jobs) {
        if ($active -ge $script:Concurrency) { break }
        if ($job.State -ne 'queued') { continue }
        $id = [Guid]::NewGuid().ToString('N')
        $job.StatusFile = Join-Path $script:JobRoot ($id + '.json')
        $job.LogFile = Join-Path $script:JobRoot ($id + '.log')
        $arguments = '-E -s -u -m video_tool.windows_worker --source ' + (Quote $job.Source) +
            ' --output ' + (Quote $script:OutputRoot) + ' --status ' + (Quote $job.StatusFile) +
            ' --height ' + $script:Height + ' --sensitivity ' + $script:SensitivityValue +
            ' --profile ' + $script:JobProfile + ' --encoder ' + $script:JobEncoder
        if ($script:UseEffects) { $arguments += ' --border' } else { $arguments += ' --no-effects' }
        if (!$script:JobUseCache) { $arguments += ' --no-cache' }
        try {
            $job.Process = Start-Process -FilePath (Join-Path $script:Root 'runtime\python.exe') `
                -ArgumentList $arguments -WorkingDirectory $script:Root -WindowStyle Hidden `
                -RedirectStandardError $job.LogFile -PassThru
            $null = $job.Process.Handle
            $job.State = 'running'
            $grid.Rows[$job.Row].Cells[2].Value = 'Đang khởi động'
            $active++
        } catch {
            $job.State = 'error'
            $grid.Rows[$job.Row].Cells[2].Value = 'Lỗi khởi động: ' + $_.Exception.Message
        }
    }
}
function Stop-Batch {
    $script:Cancelled = $true
    foreach ($job in $script:Jobs) {
        if ($job.State -eq 'running') {
            # Terminate only the worker owned by this application and its FFmpeg children.
            try {
                if (!$job.Process.HasExited) {
                    & "$env:SystemRoot\System32\taskkill.exe" /PID $job.Process.Id /T /F 2>&1 | Out-Null
                }
            } catch {}
            $job.State = 'cancelled'
            $grid.Rows[$job.Row].Cells[2].Value = 'Đã hủy; có thể còn tệp xuất dở'
        } elseif ($job.State -eq 'queued') {
            $job.State = 'cancelled'
            $grid.Rows[$job.Row].Cells[2].Value = 'Đã hủy'
        }
    }
    $script:Running = $false
    Set-Controls $true
    $summary.Text = 'Đã hủy hàng đợi. Video gốc không bị thay đổi.'
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Video Focus v0.2.1 — Công cụ video dọc tự động'
$form.Size = New-Object System.Drawing.Size(1060,760)
$form.MinimumSize = New-Object System.Drawing.Size(900,650)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)
$form.BackColor = [Drawing.Color]::FromArgb(245,247,251)
$form.AllowDrop = $true
$title = New-Object System.Windows.Forms.Label
$title.Text = 'Video Focus'
$title.Font = New-Object System.Drawing.Font('Segoe UI',25,[Drawing.FontStyle]::Bold)
$title.Location = New-Object Drawing.Point(24,18)
$title.Size = New-Object Drawing.Size(400,52)
$form.Controls.Add($title)
$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = '16:9 → 9:16 · Bám chủ thể · Giữ toàn cảnh · Xử lý nhiều video tự động'
$subtitle.Location = New-Object Drawing.Point(28,78)
$subtitle.Size = New-Object Drawing.Size(950,28)
$form.Controls.Add($subtitle)
function Button($text,$x,$y,$width) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object Drawing.Point($x,$y); $b.Size = New-Object Drawing.Size($width,34)
    $form.Controls.Add($b); return $b
}
$add = Button 'Thêm video…' 26 118 140
$clear = Button 'Xóa danh sách' 176 118 140
$folderLabel = New-Object Windows.Forms.Label
$folderLabel.Text = 'Thư mục xuất:'; $folderLabel.Location = New-Object Drawing.Point(28,174); $folderLabel.AutoSize=$true
$form.Controls.Add($folderLabel)
$out = New-Object Windows.Forms.TextBox
$out.Location = New-Object Drawing.Point(150,170); $out.Size = New-Object Drawing.Size(710,30)
$out.Anchor = 'Top,Left,Right'
$videos = [Environment]::GetFolderPath('MyVideos')
if (!$videos) { $videos = [Environment]::GetFolderPath('MyDocuments') }
$out.Text = Join-Path $videos 'Video Focus'
$form.Controls.Add($out)
$choose = Button 'Chọn…' 875 167 140
$choose.Anchor = 'Top,Right'
$resolution = New-Object Windows.Forms.ComboBox
$resolution.DropDownStyle = 'DropDownList'; $resolution.Location = New-Object Drawing.Point(26,222)
$resolution.Size = New-Object Drawing.Size(150,30)
$resolution.Items.AddRange(@('360 × 640','720 × 1280','1080 × 1920')); $resolution.SelectedIndex=1
$form.Controls.Add($resolution)
$effects = New-Object Windows.Forms.CheckBox
$effects.Text = 'Viền điểm nhấn'; $effects.Checked=$false
$effects.Location = New-Object Drawing.Point(195,221); $effects.Size = New-Object Drawing.Size(190,30)
$form.Controls.Add($effects)
$parallelLabel = New-Object Windows.Forms.Label
$parallelLabel.Text = 'Video đồng thời:'; $parallelLabel.Location=New-Object Drawing.Point(400,226); $parallelLabel.AutoSize=$true
$form.Controls.Add($parallelLabel)
$parallel = New-Object Windows.Forms.NumericUpDown
$parallel.Minimum=1; $parallel.Maximum=4; $parallel.Value=1
$parallel.Location=New-Object Drawing.Point(530,222); $parallel.Size=New-Object Drawing.Size(60,30)
$form.Controls.Add($parallel)
$sensitivityLabel = New-Object Windows.Forms.Label
$sensitivityLabel.Text='Độ nhạy:'; $sensitivityLabel.Location=New-Object Drawing.Point(615,226); $sensitivityLabel.AutoSize=$true
$form.Controls.Add($sensitivityLabel)
$sensitivity = New-Object Windows.Forms.NumericUpDown
$sensitivity.Minimum=0; $sensitivity.Maximum=100; $sensitivity.Value=50
$sensitivity.Location=New-Object Drawing.Point(700,222); $sensitivity.Size=New-Object Drawing.Size(70,30)
$form.Controls.Add($sensitivity)
$profileLabel = New-Object Windows.Forms.Label
$profileLabel.Text='Chế độ:'; $profileLabel.Location=New-Object Drawing.Point(28,274); $profileLabel.AutoSize=$true
$form.Controls.Add($profileLabel)
$uiProfile = New-Object Windows.Forms.ComboBox
$uiProfile.DropDownStyle='DropDownList'; $uiProfile.Location=New-Object Drawing.Point(100,270)
$uiProfile.Size=New-Object Drawing.Size(150,30)
$uiProfile.Items.AddRange(@('Máy nhẹ','Cân bằng','Nhanh')); $uiProfile.SelectedIndex=2
$form.Controls.Add($uiProfile)
$encoderLabel = New-Object Windows.Forms.Label
$encoderLabel.Text='Mã hóa:'; $encoderLabel.Location=New-Object Drawing.Point(275,274); $encoderLabel.AutoSize=$true
$form.Controls.Add($encoderLabel)
$uiEncoder = New-Object Windows.Forms.ComboBox
$uiEncoder.DropDownStyle='DropDownList'; $uiEncoder.Location=New-Object Drawing.Point(355,270)
$uiEncoder.Size=New-Object Drawing.Size(165,30)
$uiEncoder.Items.AddRange(@('CPU','Tự chọn GPU','NVIDIA RTX / NVENC')); $uiEncoder.SelectedIndex=2
$form.Controls.Add($uiEncoder)
$uiUseCache = New-Object Windows.Forms.CheckBox
$uiUseCache.Text='Dùng lại dữ liệu phân tích'; $uiUseCache.Checked=$true
$uiUseCache.Location=New-Object Drawing.Point(545,269); $uiUseCache.Size=New-Object Drawing.Size(300,30)
$form.Controls.Add($uiUseCache)
$library = Button 'Mở thư viện phân tích' 26 310 235
$cacheNote = New-Object Windows.Forms.Label
$cacheNote.Text='Khung hình ổn định ít nhất 5 giây; không zoom tự động. Thư viện chỉ lưu số liệu.'
$cacheNote.Location=New-Object Drawing.Point(280,314); $cacheNote.Size=New-Object Drawing.Size(735,28)
$cacheNote.Anchor='Top,Left,Right'
$form.Controls.Add($cacheNote)
$grid = New-Object Windows.Forms.DataGridView
$grid.Location=New-Object Drawing.Point(26,355); $grid.Size=New-Object Drawing.Size(990,219)
$grid.Anchor='Top,Bottom,Left,Right'; $grid.ReadOnly=$true; $grid.AllowUserToAddRows=$false; $grid.AllowUserToDeleteRows=$false
$grid.RowHeadersVisible=$false; $grid.SelectionMode='FullRowSelect'; $grid.MultiSelect=$false
$grid.AutoSizeColumnsMode='Fill'; $grid.BackgroundColor=[Drawing.Color]::White
[void]$grid.Columns.Add('name','Video gốc'); [void]$grid.Columns.Add('progress','Tiến độ'); [void]$grid.Columns.Add('status','Trạng thái')
foreach ($column in $grid.Columns) { $column.SortMode='NotSortable' }
$grid.Columns[0].FillWeight=40; $grid.Columns[1].FillWeight=12; $grid.Columns[2].FillWeight=48
$form.Controls.Add($grid)
$start = Button 'Xử lý tất cả' 26 593 160
$cancel = Button 'Hủy hàng đợi' 198 593 160; $cancel.Enabled=$false
$open = Button 'Mở kết quả' 370 593 160
foreach($b in @($start,$cancel,$open)) { $b.Anchor='Bottom,Left' }
$summary=New-Object Windows.Forms.Label
$summary.Text='Chọn hoặc kéo thả video vào cửa sổ để bắt đầu.'
$summary.Location=New-Object Drawing.Point(26,638); $summary.Size=New-Object Drawing.Size(980,26); $summary.Anchor='Bottom,Left,Right'
$form.Controls.Add($summary)
$note=New-Object Windows.Forms.Label
$note.Text='Xử lý trên máy của bạn. Nhận diện người nói/cao trào là ước lượng từ hình ảnh và âm thanh; hãy kiểm tra đầu ra.'
$note.Location=New-Object Drawing.Point(26,675); $note.Size=New-Object Drawing.Size(980,32); $note.Anchor='Bottom,Left,Right'
$form.Controls.Add($note)

$add.Add_Click({
    $dialog=New-Object Windows.Forms.OpenFileDialog
    $dialog.Filter='Video|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.m4v|Tất cả|*.*'; $dialog.Multiselect=$true
    if($dialog.ShowDialog() -eq 'OK'){ Add-Videos $dialog.FileNames }; $dialog.Dispose()
})
$clear.Add_Click({ $script:Jobs.Clear(); $grid.Rows.Clear(); $summary.Text='Chọn video để bắt đầu.' })
$uiProfile.Add_SelectedIndexChanged({
    if($uiProfile.SelectedIndex -ge 0){ $parallel.Value=1 }
})
$library.Add_Click({
    try{
        New-Item -ItemType Directory -Force -Path $script:CacheRoot | Out-Null
        Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote $script:CacheRoot) | Out-Null
    }catch{ Info $_.Exception.Message }
})
$choose.Add_Click({
    $dialog=New-Object Windows.Forms.FolderBrowserDialog
    if($dialog.ShowDialog() -eq 'OK'){ $out.Text=$dialog.SelectedPath }; $dialog.Dispose()
})
$form.Add_DragEnter({ if(!$script:Running -and $_.Data.GetDataPresent('FileDrop')){ $_.Effect='Copy' } })
$form.Add_DragDrop({ Add-Videos $_.Data.GetData('FileDrop') })
$open.Add_Click({
    $path=$out.Text
    if($grid.SelectedRows.Count -gt 0){
        $job=$script:Jobs[$grid.SelectedRows[0].Index]
        if($job.Output){ $path=$job.Output }
    }
    if(Test-Path -LiteralPath $path){ Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote $path) | Out-Null }
})
function Start-Batch {
    if($script:Running) { return }
    try {
        if($script:Jobs.Count -eq 0){ Info 'Hãy thêm ít nhất một video.'; return }
        foreach($relative in @('runtime\python.exe','tools\ffmpeg.exe','tools\ffprobe.exe')){
            if(!(Test-Path -LiteralPath (Join-Path $script:Root $relative))){ Info 'Gói ứng dụng chưa đầy đủ. Hãy giải nén toàn bộ tệp ZIP.'; return }
        }
        try{
            if([string]::IsNullOrWhiteSpace($out.Text)){ throw 'Hãy chọn thư mục xuất.' }
            [void][IO.Directory]::CreateDirectory($out.Text)
            $script:OutputRoot=[IO.Path]::GetFullPath($out.Text)
        }catch{ Info $_.Exception.Message; return }
        $script:Height=Resolve-UiChoice $resolution @(640,1280,1920) 1
        $script:Concurrency=[int]$parallel.Value
        $script:SensitivityValue=([double]$sensitivity.Value/100).ToString([Globalization.CultureInfo]::InvariantCulture)
        $script:UseEffects=$effects.Checked
        $script:JobProfile=Resolve-UiChoice $uiProfile @('light','balanced','fast') 2
        $script:JobEncoder=Resolve-UiChoice $uiEncoder @('cpu','auto','nvenc') 2
        $script:JobUseCache=$uiUseCache.Checked
        $script:Cancelled=$false; $script:Running=$true
        foreach($job in $script:Jobs){
            $job.State='queued'; $job.Process=$null; $job.Output=''; $job.StatusFile=''
            $grid.Rows[$job.Row].Cells[1].Value='0%'; $grid.Rows[$job.Row].Cells[2].Value='Đang chờ'
        }
        Set-Controls $false; Launch-Next
    } catch {
        $record=$_
        $script:Running=@($script:Jobs | Where-Object { $_.State -eq 'running' }).Count -gt 0
        if(!$script:Running) { Set-Controls $true }
        Report-UiError $record
    }
}
$start.Add_Click({ Start-Batch })
$cancel.Add_Click({ Stop-Batch })
$timer=New-Object Windows.Forms.Timer
$timer.Interval=400
$timer.Add_Tick({
    if(!$script:Running){ return }
    foreach($job in $script:Jobs){
        if($job.State -ne 'running'){ continue }
        $state=$null
        if(Test-Path -LiteralPath $job.StatusFile){
            try{
                $stream=[IO.File]::Open($job.StatusFile,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
                $reader=New-Object IO.StreamReader($stream,[Text.Encoding]::UTF8)
                try { $state=$reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
                $grid.Rows[$job.Row].Cells[1].Value="$($state.progress)%"
                $grid.Rows[$job.Row].Cells[2].Value=$state.message
                $job.Output=$state.output
            }catch{}
        }
        if($job.Process.HasExited){
            $job.Process.WaitForExit()
            if($state -and $state.state -eq 'done' -and $job.Process.ExitCode -eq 0){ $job.State='done' }
            else{
                $job.State='error'
                if(!$state -or $state.state -ne 'error'){
                    $grid.Rows[$job.Row].Cells[2].Value='Lỗi xử lý. Xem nhật ký: ' + $job.LogFile
                }
            }
            $job.Process.Dispose()
        }
    }
    Launch-Next
    $done=@($script:Jobs | Where-Object {$_.State -eq 'done'}).Count
    $errors=@($script:Jobs | Where-Object {$_.State -eq 'error'}).Count
    $pending=@($script:Jobs | Where-Object {$_.State -in @('queued','running')}).Count
    $summary.Text="Hoàn tất: $done · Lỗi: $errors · Còn: $pending"
    if($pending -eq 0){ $script:Running=$false; Set-Controls $true }
})
$form.Add_FormClosing({
    if($script:Running){
        $answer=[Windows.Forms.MessageBox]::Show('Hủy các video đang xử lý và đóng ứng dụng?', 'Video Focus', 'YesNo','Question')
        if($answer -ne 'Yes'){ $_.Cancel=$true; return }; Stop-Batch
    }
    $timer.Stop()
})
$timer.Start()
try { [void]$form.ShowDialog() } finally { $timer.Dispose(); $form.Dispose() }
