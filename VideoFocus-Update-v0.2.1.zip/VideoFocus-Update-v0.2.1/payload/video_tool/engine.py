"""Bounded-resource reframing, stable framing and optional hardware encoding."""
import json
import math
import os
import subprocess
from pathlib import Path

import cv2
import numpy as np

PROFILES = {
    'light': {'opencv_threads': 1, 'decode_threads': 1, 'encode_threads': 1},
    'balanced': {'opencv_threads': 1, 'decode_threads': 2, 'encode_threads': 2},
    'fast': {'opencv_threads': 2, 'decode_threads': 2, 'encode_threads': 2},
}
ANALYSIS_VERSION = 'stable-framing-2'


def creation_flags(profile='balanced'):
    if os.name != 'nt':
        return 0
    return subprocess.CREATE_NO_WINDOW | (subprocess.BELOW_NORMAL_PRIORITY_CLASS if profile == 'light' else 0)


def run(args):
    result = subprocess.run(args, capture_output=True, creationflags=creation_flags())
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace')[-3000:])
    return result.stdout


def probe(path):
    info = json.loads(run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)]))
    video = next((s for s in info['streams'] if s['codec_type'] == 'video'), None)
    if not video:
        raise ValueError('Tệp không có luồng video.')
    duration = float(info['format'].get('duration', video.get('duration', 0)))
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError('Không xác định được thời lượng video.')
    return {'duration': duration, 'audio': any(s['codec_type'] == 'audio' for s in info['streams'])}


def open_capture(source, profile):
    settings = PROFILES[profile]
    cv2.setNumThreads(settings['opencv_threads'])
    cap = cv2.VideoCapture(str(source), cv2.CAP_FFMPEG,
                           [cv2.CAP_PROP_N_THREADS, settings['decode_threads']])
    if not cap.isOpened():
        cap.release()
        raise ValueError('Không mở được video bằng bộ giải mã FFmpeg.')
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not math.isfinite(fps) or fps <= 0 or fps > 240:
        cap.release()
        raise ValueError('Tốc độ khung hình không được hỗ trợ (1–240 fps).')
    return cap, fps


def audio_levels(source, directory, info, profile='balanced'):
    """Stream audio into tiny RMS blocks instead of writing an intermediate WAV."""
    if not info['audio']:
        return np.zeros(int(info['duration'] * 4) + 2)
    levels = []
    log_path = directory/'audio-analysis.log'
    args = ['ffmpeg', '-v', 'error', '-threads', '1', '-i', str(source), '-vn', '-ac', '1',
            '-ar', '8000', '-f', 's16le', 'pipe:1']
    with log_path.open('wb') as log:
        process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=log, creationflags=creation_flags(profile))
        try:
            while data := process.stdout.read(4000):
                samples = np.frombuffer(data, np.int16).astype(np.float32) / 32768
                levels.append(float(np.sqrt(np.mean(samples * samples))))
        finally:
            process.stdout.close()
            code = process.wait()
    if code:
        raise RuntimeError(log_path.read_text(errors='replace')[-3000:])
    log_path.unlink(missing_ok=True)
    return np.array(levels or [0.0])


def stabilize_plan(samples, enter_after=1.5, exit_after=3.0, min_hold=5.0):
    """Require sustained activity/inactivity and a minimum dwell between modes."""
    mode = False
    changed = -min_hold
    candidate = None
    candidate_since = 0.0
    center = .5
    subject_since = None
    pending_center = None
    for sample in samples:
        t = sample['time']
        if sample['cut']:
            mode, changed, candidate = False, t, None
            pending_center, subject_since = None, None
        desired = bool(sample['focus'])
        if desired != mode:
            if candidate != desired:
                candidate, candidate_since = desired, t
            delay = enter_after if desired else exit_after
            if t-candidate_since >= delay and t-changed >= min_hold:
                mode, changed, candidate = desired, t, None
                if mode:
                    center = sample['x']
        else:
            candidate = None
        # A large proposed change of subject must persist before the camera follows.
        if not desired:
            pending_center, subject_since = None, None
        if mode and desired and abs(sample['x']-center) > .2:
            if pending_center is None or abs(sample['x']-pending_center) > .1:
                pending_center, subject_since = sample['x'], t
            if t-subject_since >= 2.0:
                center = sample['x']
                pending_center, subject_since = None, None
        elif mode and desired:
            center = sample['x']
            pending_center, subject_since = None, None
        sample['focus'] = mode
        sample['x'] = center if mode else sample['x']
    return samples


def analyze(source, directory, sensitivity=0.5, progress=lambda *_: None, *, profile='balanced'):
    info = probe(source)
    levels = audio_levels(source, directory, info, profile)
    audio_gate = max(.012, float(np.percentile(levels, 45)) * .8)
    loud_gate = max(.08, float(np.percentile(levels, 90)))
    cascade_xml = Path(cv2.data.haarcascades, 'haarcascade_frontalface_default.xml').read_text(encoding='utf-8')
    storage = cv2.FileStorage(cascade_xml, cv2.FILE_STORAGE_READ | cv2.FILE_STORAGE_MEMORY)
    detector = cv2.CascadeClassifier()
    detector.read(storage.getFirstTopLevelNode())
    storage.release()
    if detector.empty():
        raise RuntimeError('Không nạp được bộ nhận diện khuôn mặt.')
    cap, fps = open_capture(source, profile)
    samples, previous, previous_faces = [], None, []
    step = max(1, round(fps / 4))
    index = 0
    try:
        # grab() decodes predictive frames but avoids BGR conversion/copy for unused ones.
        while cap.grab():
            if index % step:
                index += 1
                continue
            ok, frame = cap.retrieve()
            if not ok:
                break
            t = index / fps
            h, w = frame.shape[:2]
            small = cv2.resize(frame, (480, max(1, round(h * 480 / w))))
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            diff = 0 if previous is None else float(np.mean(cv2.absdiff(gray, previous))) / 255
            cut = diff > .23
            faces = detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(24, 24))
            candidates, current_faces = [], []
            for x, y, fw, fh in faces:
                mouth = cv2.resize(gray[y + fh * 2 // 3:y + fh, x:x + fw], (32, 16))
                cx = (x + fw / 2) / gray.shape[1]
                cy = (y + fh / 2) / gray.shape[0]
                nearest = min(previous_faces, key=lambda p: (p[0]-cx)**2 + (p[1]-cy)**2, default=None)
                mouth_motion = 0.0
                if nearest and not cut and abs(nearest[0] - cx) < .15 and abs(nearest[1] - cy) < .15:
                    mouth_motion = float(np.mean(cv2.absdiff(mouth, nearest[2]))) / 255
                candidates.append((mouth_motion * 3 + fw / gray.shape[1] * .15, cx, cy, mouth_motion))
                current_faces.append((cx, cy, mouth))
            level = float(levels[min(len(levels)-1, int(t*4))])
            best = max(candidates, default=None)
            speaking = bool(best and level > audio_gate and best[3] > .018)
            action = bool(not cut and diff > (.025 + (1-sensitivity)*.07))
            focus = bool(best and (speaking or action))
            highlight = bool(not cut and (action or (level > loud_gate and speaking)))
            samples.append({'time': round(t, 3), 'x': best[1] if best else .5,
                            'y': best[2] if best else .5, 'focus': focus,
                            'highlight': highlight, 'speaking': speaking,
                            'motion': round(diff, 4), 'cut': bool(cut)})
            previous, previous_faces = gray, current_faces
            index += 1
            if len(samples) % 16 == 0:
                progress(min(.4, t / info['duration'] * .4), 'Đang phân tích chủ thể và chuyển động')
    finally:
        cap.release()
    if not samples:
        raise ValueError('Video không có khung hình giải mã được.')
    stabilize_plan(samples)
    report = {'info': info, 'samples': samples, 'analysis_version': ANALYSIS_VERSION,
              'method': 'Haar faces + mouth motion/audio RMS + frame motion; stable framing; heuristic only'}
    (directory / 'analysis.json').write_text(json.dumps(report, ensure_ascii=False), encoding='utf-8')
    return report


def choose_encoder(requested, profile):
    """A listed encoder is insufficient: perform an actual short encoding probe."""
    if requested not in ('cpu', 'auto', 'nvenc'):
        raise ValueError('Bộ mã hóa không hợp lệ.')
    hardware = {
        'h264_nvenc': ['-c:v', 'h264_nvenc', '-preset', 'p4', '-cq', '22', '-b:v', '0'],
        'h264_qsv': ['-c:v', 'h264_qsv', '-preset', 'veryfast', '-global_quality', '22'],
        'h264_amf': ['-c:v', 'h264_amf', '-quality', 'speed', '-rc', 'cqp', '-qp_i', '22', '-qp_p', '22'],
    }
    candidates = [] if requested == 'cpu' else (['h264_nvenc'] if requested == 'nvenc' else list(hardware))
    failures = []
    for name in candidates:
        args = ['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i', 'color=size=256x256:rate=10:duration=0.2',
                '-frames:v', '2', *hardware[name], '-pix_fmt', 'yuv420p', '-f', 'null', '-']
        try:
            result = subprocess.run(args, capture_output=True, timeout=8, creationflags=creation_flags(profile))
            if result.returncode == 0:
                return name, hardware[name], ''
            failures.append(name+': '+result.stderr.decode(errors='replace')[-350:])
        except (OSError, subprocess.TimeoutExpired) as exc:
            failures.append(name+': '+type(exc).__name__)
    return 'libx264', ['-c:v', 'libx264', '-threads:v', str(PROFILES[profile]['encode_threads']),
                       '-preset', 'veryfast', '-crf', '22'], '\n'.join(failures)


def render(source, directory, report, height=640, effects=False, progress=lambda *_: None,
           *, profile='balanced', encoder='cpu', export_images=False):
    width = height * 9 // 16
    width += width % 2
    cap, fps = open_capture(source, profile)
    selected, encoder_args, fallback = choose_encoder(encoder, profile)
    (directory/'encoding.json').write_text(json.dumps({'requested':encoder,'used':selected,'fallback':fallback,
                                                      'profile':profile,'threads':PROFILES[profile]}),encoding='utf-8')
    output_path = directory/'output.mp4'
    # Mux audio while encoding; no silent intermediate file or second mux pass.
    command = ['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', f'{width}x{height}',
               '-r', str(fps), '-i', 'pipe:0', '-threads', '1', '-i', str(source),
               '-map', '0:v:0', '-map', '1:a:0?', *encoder_args, '-pix_fmt', 'yuv420p',
               '-c:a', 'aac', '-threads:a', '1', '-b:a', '160k', '-shortest', '-movflags', '+faststart', str(output_path)]
    errors = directory/'encoder.log'
    count, sample_index, alpha, center, last_shot = 0, 0, 0., .5, -10.
    samples, shots = report['samples'], []
    blur_w = min(180, width)
    blur_h = max(1, round(height*blur_w/width))
    mode_smoothing = 1-math.exp(-1/(fps*.8))
    pan_smoothing = 1-math.exp(-1/(fps*1.0))
    max_pan_step = .12/fps
    try:
        with errors.open('wb') as log:
            process = subprocess.Popen(command, stdin=subprocess.PIPE, stderr=log, creationflags=creation_flags(profile))
            try:
                while True:
                    ok, frame = cap.read()
                    if not ok:
                        break
                    t = count/fps
                    while sample_index+1 < len(samples) and samples[sample_index+1]['time'] <= t:
                        sample_index += 1
                    sample = samples[sample_index]
                    h, w = frame.shape[:2]
                    target = float(sample['focus']) if w/h > 9/16 else 0.
                    alpha += (target-alpha)*mode_smoothing
                    if alpha < .002: alpha = 0.
                    if alpha > .998: alpha = 1.
                    if abs(sample['x']-center) > .04:
                        delta = (sample['x']-center)*pan_smoothing
                        center += max(-max_pan_step, min(max_pan_step, delta))
                    # Build only layers which will actually contribute to this frame.
                    if alpha < 1:
                        small = cv2.resize(frame, (blur_w, blur_h), interpolation=cv2.INTER_AREA)
                        small = cv2.GaussianBlur(small, (0,0), max(.5, 20*blur_w/width))
                        background = cv2.resize(small, (width,height))
                        ratio = min(width/w,height/h)
                        fit = cv2.resize(frame, (max(1,round(w*ratio)),max(1,round(h*ratio))))
                        fh,fw = fit.shape[:2]
                        top,left = (height-fh)//2,(width-fw)//2
                        background[top:top+fh,left:left+fw] = fit
                    if alpha > 0:
                        crop_w = min(w,max(1,round(h*9/16)))
                        x = max(0,min(w-crop_w,round(center*w-crop_w/2)))
                        crop = cv2.resize(frame[:,x:x+crop_w],(width,height))
                    output = background if alpha==0 else crop if alpha==1 else cv2.addWeighted(background,1-alpha,crop,alpha,0)
                    # Optional border only. Automatic zoom pulses are intentionally removed.
                    if effects and sample['highlight']:
                        cv2.rectangle(output,(2,2),(width-3,height-3),(60,200,255),3)
                    if export_images and sample['highlight'] and t-last_shot>=4:
                        name=f'highlight-{len(shots)+1:03d}.jpg'
                        success,encoded=cv2.imencode('.jpg',frame)
                        if not success: raise RuntimeError('Không mã hóa được ảnh điểm nhấn.')
                        (directory/name).write_bytes(encoded.tobytes())
                        shots.append({'time':round(t,2),'file':name}); last_shot=t
                    process.stdin.write(memoryview(output))
                    count += 1
                    if count % max(1,round(fps))==0:
                        progress(.4+min(.55,t/report['info']['duration']*.55),'Đang xuất video · '+selected)
            finally:
                try: process.stdin.close()
                except BrokenPipeError: pass
                code=process.wait()
            if code:
                raise RuntimeError(errors.read_text(errors='replace')[-3000:])
    finally:
        cap.release()
    if not count:
        raise ValueError('Không xuất được khung hình nào.')
    if export_images:
        (directory/'highlights.json').write_text(json.dumps(shots),encoding='utf-8')
    return shots
